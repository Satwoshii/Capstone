import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'login/services/jwt_service.dart';
import '../studentvw_pages/login/services/ai_helper_service.dart';

const Color _nuDarkBlue = Color(0xFF001A52);
const Color _nuGold = Color(0xFFFFD700);
const Color _nuWhite = Color(0xFFF8F9FF);

class StudentReportFormPage extends StatefulWidget {
  final String? pcCode;
  final String? initialStudentName;
  final String? initialStudentEmail;

  const StudentReportFormPage({
    super.key,
    this.pcCode,
    this.initialStudentName,
    this.initialStudentEmail,
  });

  @override
  State<StudentReportFormPage> createState() => _StudentReportFormPageState();
}

class _StudentReportFormPageState extends State<StudentReportFormPage>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _commentCtrl = TextEditingController();

  bool _mouseOk = true;
  bool _keyboardOk = true;
  bool _monitorOk = true;
  bool _cablesOk = true;
  bool _systemUnitOk = true;

  bool _loading = true;
  bool _submitting = false;
  bool _loadingAi = false;

  String? _pcCode;
  String? _lab;
  String? _pcLabel;

  AiHelperResult? _aiResult;
  bool _showAiSuggestion = false;

  bool _aiTriedFix = false;
  bool? _aiSolved;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _loadPageData();

    _fadeCtrl = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _commentCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadPageData() async {
    await _loadLoggedInUser();
    await _loadPcData();
    if (mounted) {
      setState(() => _loading = false);
      _fadeCtrl.forward();
    }
  }

  Future<void> _loadLoggedInUser() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString("token");

      if (token == null || token.isEmpty) {
        _nameCtrl.text = (widget.initialStudentName ?? 'Student').trim();
        _emailCtrl.text = (widget.initialStudentEmail ?? '').trim();
        return;
      }

      final payload = JWTService.verifyToken(token);

      if (payload == null) {
        _nameCtrl.text = (widget.initialStudentName ?? 'Student').trim();
        _emailCtrl.text = (widget.initialStudentEmail ?? '').trim();
        return;
      }

      final String uid = (payload['uid'] ?? '').toString();
      final String tokenName =
      (payload['full_name'] ?? payload['name'] ?? 'Student').toString();
      final String tokenEmail = (payload['email'] ?? '').toString();

      if (uid.isNotEmpty) {
        final userDoc =
        await FirebaseFirestore.instance.collection('users').doc(uid).get();

        if (userDoc.exists) {
          final data = userDoc.data() ?? {};
          _nameCtrl.text =
              (data['full_name'] ?? data['name'] ?? tokenName).toString().trim();
          _emailCtrl.text = (data['email'] ?? tokenEmail).toString().trim();
          return;
        }
      }

      _nameCtrl.text = tokenName.trim();
      _emailCtrl.text = tokenEmail.trim();
    } catch (_) {
      _nameCtrl.text = (widget.initialStudentName ?? 'Student').trim();
      _emailCtrl.text = (widget.initialStudentEmail ?? '').trim();
    }
  }

  Future<void> _loadPcData() async {
    try {
      String? code = widget.pcCode;

      if (code == null || code.isEmpty) {
        final uri = Uri.base;
        code = uri.queryParameters['code'];
      }

      if (code == null || code.isEmpty) return;

      final doc =
      await FirebaseFirestore.instance.collection('pcs').doc(code).get();

      if (!doc.exists) {
        _pcCode = code;
        return;
      }

      final data = doc.data()!;
      _pcCode = code;
      _lab = (data['lab'] ?? '').toString();
      _pcLabel = (data['pc'] ?? '').toString();
    } catch (_) {}
  }

  Future<void> _openAiHelper() async {
    if (_pcCode == null || _lab == null || _pcLabel == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Missing PC information.')),
      );
      return;
    }

    setState(() {
      _loadingAi = true;
      _showAiSuggestion = false;
      _aiResult = null;
      _aiTriedFix = false;
      _aiSolved = null;
    });

    final result = await AiHelperService.generate(
      pcCode: _pcCode!,
      lab: _lab!,
      pc: _pcLabel!,
      comment: _commentCtrl.text.trim().isEmpty
          ? 'Student reported an issue.'
          : _commentCtrl.text.trim(),
      peripherals: {
        'mouse': _mouseOk,
        'keyboard': _keyboardOk,
        'monitor': _monitorOk,
        'cables': _cablesOk,
        'system_unit': _systemUnitOk,
      },
    );

    if (!mounted) return;

    setState(() {
      _loadingAi = false;
      _aiResult = result;
      _showAiSuggestion = result != null;
    });

    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('AI helper failed. Check logs.')),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('AI Helper'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Category: ${result.category}'),
            Text('Priority: ${result.priority}'),
            const SizedBox(height: 10),
            Text('Tip: ${result.studentTip}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  String _buildAttemptSummary({
    required String originalComment,
    required AiHelperResult aiResult,
    required bool solved,
  }) {
    final cleanComment = originalComment.trim().isEmpty
        ? 'Student reported a workstation issue.'
        : originalComment.trim();

    if (solved) {
      return 'Student reported: "$cleanComment". '
          'The student followed the AI helper instruction: "${aiResult.studentTip}". '
          'The student confirmed that the issue was fixed.';
    }

    return 'Student reported: "$cleanComment". '
        'The student followed the AI helper instruction: "${aiResult.studentTip}". '
        'Result: issue not resolved. ${aiResult.actionDoneTemplate}';
  }

  Future<void> _submitReport() async {
    if (!_formKey.currentState!.validate()) return;
    if (_pcCode == null || _pcCode!.isEmpty) return;

    setState(() => _submitting = true);

    final studentName = _nameCtrl.text.trim();
    final studentEmail = _emailCtrl.text.trim().toLowerCase();

    final peripherals = {
      'mouse': _mouseOk,
      'keyboard': _keyboardOk,
      'monitor': _monitorOk,
      'cables': _cablesOk,
      'system_unit': _systemUnitOk,
    };

    bool hasProblem = peripherals.values.any((e) => e == false);

    if (_aiSolved == true) {
      hasProblem = false;
    }

    final bool reportHealthy = _aiSolved == true;
    final bool sendToItso = _aiSolved != true;

    final String aiAttemptSummary = _aiResult == null
        ? _commentCtrl.text.trim()
        : _buildAttemptSummary(
      originalComment: _commentCtrl.text.trim(),
      aiResult: _aiResult!,
      solved: _aiSolved == true,
    );

    try {
      await FirebaseFirestore.instance.collection('reports').add({
        'pc_code': _pcCode,
        'lab': _lab ?? '',
        'pc': _pcLabel ?? '',
        'student_name': studentName,
        'student_email': studentEmail,
        'reported_by': studentName,
        'reported_by_name': studentName,
        'reported_by_email': studentEmail,
        'comment': _commentCtrl.text.trim(),
        'peripherals': peripherals,
        'timestamp': FieldValue.serverTimestamp(),
        'status': reportHealthy ? 'healthy' : 'pending',
        'report_route': reportHealthy ? 'healthy' : 'itso',
        'ai_category': _aiResult?.category ?? '',
        'ai_priority': _aiResult?.priority ?? '',
        'ai_student_tip': _aiResult?.studentTip ?? '',
        'ai_action_done_template': _aiResult?.actionDoneTemplate ?? '',
        'ai_escalate_to_itso': _aiResult?.escalateToItso ?? sendToItso,
        'ai_itso_action': _aiResult?.itsoAction ?? '',
        'ai_attempted_fix': _showAiSuggestion,
        'ai_resolved': _aiSolved == true,
        'ai_attempt_summary': aiAttemptSummary,
      });

      await FirebaseFirestore.instance.collection('attendance').add({
        'student_name': studentName,
        'student_email': studentEmail,
        'lab': _lab ?? '',
        'pc': _pcLabel ?? '',
        'present': 1.0,
        'late': 0.0,
        'attendance_score': 1.0,
        'date': DateTime.now().toString().split(' ')[0],
        'timestamp': FieldValue.serverTimestamp(),
      });

      await FirebaseFirestore.instance.collection('pcs').doc(_pcCode).update({
        'status': hasProblem ? 'problem' : 'available',
        'comment': _commentCtrl.text.trim(),
        'reported_by': studentName,
        'reported_by_name': studentName,
        'reported_by_email': studentEmail,
        'updated_at': FieldValue.serverTimestamp(),
        'peripherals': peripherals,
        'ai_category': _aiResult?.category ?? '',
        'ai_priority': _aiResult?.priority ?? '',
        'ai_student_tip': _aiResult?.studentTip ?? '',
        'ai_escalate_to_itso': _aiResult?.escalateToItso ?? sendToItso,
        'ai_itso_action': _aiResult?.itsoAction ?? '',
        'ai_attempted_fix': _showAiSuggestion,
        'ai_resolved': _aiSolved == true,
        'ai_attempt_summary': aiAttemptSummary,
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            reportHealthy
                ? 'Problem fixed. Report saved as healthy.'
                : 'Problem submitted.',
          ),
          backgroundColor:
          reportHealthy ? const Color(0xFF3B6D11) : _nuDarkBlue,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      );

      _commentCtrl.clear();

      setState(() {
        _mouseOk = true;
        _keyboardOk = true;
        _monitorOk = true;
        _cablesOk = true;
        _systemUnitOk = true;
        _aiResult = null;
        _showAiSuggestion = false;
        _aiTriedFix = false;
        _aiSolved = null;
      });
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to submit report: $e'),
          backgroundColor: _nuDarkBlue,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _submitting = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: const Color(0xFFF4F5F8),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_pcCode == null || _pcCode!.isEmpty) {
      return _ErrorScaffold(
        message: 'Invalid QR code or unique code.',
        onBack: () => Navigator.pop(context),
      );
    }

    if (_lab == null || _pcLabel == null) {
      return _ErrorScaffold(
        message: 'PC not found for code:\n$_pcCode',
        onBack: () => Navigator.pop(context),
      );
    }

    final allOk =
        _mouseOk && _keyboardOk && _monitorOk && _cablesOk && _systemUnitOk;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F5F8),
      appBar: AppBar(
        backgroundColor: _nuDarkBlue,
        elevation: 0,
        title: const Text(
          'PC REPORT',
          style: TextStyle(color: _nuWhite, fontWeight: FontWeight.w800),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: Container(height: 3, color: _nuGold),
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SlideTransition(
          position: _slideAnim,
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 680),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: _nuDarkBlue,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '$_lab · $_pcLabel',
                              style: const TextStyle(
                                color: _nuWhite,
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              _pcCode!,
                              style: TextStyle(
                                color: _nuGold.withOpacity(0.9),
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              allOk ? 'All OK' : 'Issues detected',
                              style: TextStyle(
                                color: allOk
                                    ? const Color(0xFF9FE1CB)
                                    : const Color(0xFFFCA5A5),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      _FormPanel(
                        title: 'Student Information',
                        child: Column(
                          children: [
                            _ReadOnlyField(
                              label: 'FULL NAME',
                              controller: _nameCtrl,
                            ),
                            const SizedBox(height: 12),
                            _ReadOnlyField(
                              label: 'STUDENT EMAIL',
                              controller: _emailCtrl,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      _FormPanel(
                        title: 'Peripheral Status',
                        child: Column(
                          children: [
                            _PeripheralTile(
                              label: 'Mouse',
                              value: _mouseOk,
                              onChanged: (v) =>
                                  setState(() => _mouseOk = v ?? true),
                            ),
                            _PeripheralTile(
                              label: 'Keyboard',
                              value: _keyboardOk,
                              onChanged: (v) =>
                                  setState(() => _keyboardOk = v ?? true),
                            ),
                            _PeripheralTile(
                              label: 'Monitor',
                              value: _monitorOk,
                              onChanged: (v) =>
                                  setState(() => _monitorOk = v ?? true),
                            ),
                            _PeripheralTile(
                              label: 'Cables',
                              value: _cablesOk,
                              onChanged: (v) =>
                                  setState(() => _cablesOk = v ?? true),
                            ),
                            _PeripheralTile(
                              label: 'System Unit',
                              value: _systemUnitOk,
                              onChanged: (v) =>
                                  setState(() => _systemUnitOk = v ?? true),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      _FormPanel(
                        title: 'Comment / Issue',
                        child: TextFormField(
                          controller: _commentCtrl,
                          maxLines: 4,
                          validator: (value) {
                            if ((value ?? '').trim().isEmpty) {
                              return 'Please describe the issue first.';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            hintText:
                            'Example: The ethernet cable was unplugged and plugged back in, but the internet is still not present on this PC.',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _loadingAi ? null : _openAiHelper,
                          icon: _loadingAi
                              ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                              : const Icon(Icons.auto_awesome),
                          label: Text(
                            _loadingAi
                                ? 'Opening AI Helper...'
                                : 'Open AI Helper',
                          ),
                        ),
                      ),
                      if (_showAiSuggestion && _aiResult != null) ...[
                        const SizedBox(height: 16),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.black12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'AI Helper',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text('Issue Type: ${_aiResult!.category}'),
                              Text('Priority: ${_aiResult!.priority}'),
                              const SizedBox(height: 8),
                              Text(
                                'What you can try: ${_aiResult!.studentTip}',
                              ),
                              const SizedBox(height: 14),
                              const Text(
                                'Did the AI helper fix the problem?',
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: () {
                                        setState(() {
                                          _aiTriedFix = true;
                                          _aiSolved = true;
                                        });
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor:
                                        const Color(0xFF3B6D11),
                                        foregroundColor: Colors.white,
                                      ),
                                      child: const Text('YES, FIXED'),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: () {
                                        setState(() {
                                          _aiTriedFix = true;
                                          _aiSolved = false;
                                        });
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor:
                                        const Color(0xFFE24B4A),
                                        foregroundColor: Colors.white,
                                      ),
                                      child: const Text('NO, STILL BROKEN'),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _submitting ? null : _submitReport,
                          icon: _submitting
                              ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              color: _nuGold,
                              strokeWidth: 2,
                            ),
                          )
                              : const Icon(Icons.send_outlined),
                          label: Text(
                            _submitting ? 'Submitting...' : 'Submit Report',
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _nuDarkBlue,
                            foregroundColor: _nuGold,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _FormPanel extends StatelessWidget {
  final String title;
  final Widget child;

  const _FormPanel({
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                color: _nuDarkBlue,
              ),
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class _ReadOnlyField extends StatelessWidget {
  final String label;
  final TextEditingController controller;

  const _ReadOnlyField({
    required this.label,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      readOnly: true,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}

class _PeripheralTile extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool?> onChanged;

  const _PeripheralTile({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return CheckboxListTile(
      value: value,
      onChanged: onChanged,
      title: Text(label),
      subtitle: Text(value ? 'Working fine' : 'Has a problem'),
      controlAffinity: ListTileControlAffinity.trailing,
      contentPadding: EdgeInsets.zero,
    );
  }
}

class _ErrorScaffold extends StatelessWidget {
  final String message;
  final VoidCallback onBack;

  const _ErrorScaffold({
    required this.message,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _nuDarkBlue,
        title: const Text('PC REPORT', style: TextStyle(color: _nuWhite)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: onBack,
                child: const Text('Go Back'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}