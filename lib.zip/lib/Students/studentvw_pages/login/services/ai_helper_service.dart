import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class AiHelperResult {
  final String category;
  final String priority;
  final String studentTip;
  final bool escalateToItso;
  final String itsoAction;
  final String actionDoneTemplate;

  const AiHelperResult({
    required this.category,
    required this.priority,
    required this.studentTip,
    required this.escalateToItso,
    required this.itsoAction,
    required this.actionDoneTemplate,
  });

  factory AiHelperResult.fromMap(Map<String, dynamic> map) {
    return AiHelperResult(
      category: (map['category'] ?? '').toString(),
      priority: (map['priority'] ?? '').toString(),
      studentTip: (map['student_tip'] ?? '').toString(),
      escalateToItso: map['escalate_to_itso'] == true,
      itsoAction: (map['itso_action'] ?? '').toString(),
      actionDoneTemplate: (map['action_done_template'] ?? '').toString(),
    );
  }
}

class AiHelperService {
  static const String _url =
      'https://us-central1-test-1fc5d.cloudfunctions.net/generateStudentAiHelperHttp';

  static Future<AiHelperResult?> generate({
    required String pcCode,
    required String lab,
    required String pc,
    required String comment,
    required Map<String, bool> peripherals,
  }) async {
    try {
      final response = await http.post(
        Uri.parse(_url),
        headers: const {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'pcCode': pcCode,
          'lab': lab,
          'pc': pc,
          'comment': comment,
          'peripherals': peripherals,
        }),
      );

      debugPrint('AI STATUS: ${response.statusCode}');
      debugPrint('AI BODY: ${response.body}');

      if (response.statusCode != 200) return null;

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (data['success'] == true && data['result'] != null) {
        return AiHelperResult.fromMap(
          Map<String, dynamic>.from(data['result'] as Map),
        );
      }

      return null;
    } catch (e, st) {
      debugPrint('AI HELPER ERROR: $e');
      debugPrint('$st');
      return null;
    }
  }
}